
<?php $__env->startSection('titulo'); ?>
    Tienda
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
   Nuestros productos
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/tienda.blade.php ENDPATH**/ ?>