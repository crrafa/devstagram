
<?php $__env->startSection('titulo'); ?>
    Nosotros
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    Un poco sobre nosotros
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/nosotros.blade.php ENDPATH**/ ?>