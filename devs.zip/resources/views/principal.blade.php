@extends('layouts.app')
@section('titulo')
    Pagina Principal
@endsection

@section('contenido')
    Contenido de esta pagina    
@endsection