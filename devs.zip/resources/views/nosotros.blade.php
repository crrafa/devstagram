@extends('layouts.app')
@section('titulo')
    Nosotros
@endsection

@section('contenido')
    Un poco sobre nosotros
@endsection