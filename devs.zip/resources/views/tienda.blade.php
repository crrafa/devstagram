@extends('layouts.app')
@section('titulo')
    Tienda
@endsection

@section('contenido')
   Nuestros productos
@endsection